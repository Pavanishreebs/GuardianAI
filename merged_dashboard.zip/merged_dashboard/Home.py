import streamlit as st

st.set_page_config(page_title="GuardianAI Dashboard", layout="wide")

st.title("🛡️ GuardianAI Unified Threat Intelligence Dashboard")
st.markdown("""
Welcome to **GuardianAI** — your unified interface for:
- 🔍 **Anomaly Threat Detection** using Isolation Forest
- 🔗 **Phishing URL Detection** using Logistic Regression

Use the navigation pane to explore both tools.
""")

