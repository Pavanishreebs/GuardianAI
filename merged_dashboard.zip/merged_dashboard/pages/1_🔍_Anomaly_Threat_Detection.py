import streamlit as st
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
import matplotlib.pyplot as plt
import seaborn as sns

st.set_page_config(page_title="Anomaly Threat Detection Dashboard", layout="wide")

st.title("🔍 Anomaly Threat Detection using Isolation Forest")

# Upload CSV file
uploaded_file = st.file_uploader("Upload system activity dataset (CSV)", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.subheader("Dataset Preview")
    st.dataframe(df.head())

    # Select features for anomaly detection
    with st.expander("🔧 Feature Selection"):
        selected_features = st.multiselect("Select features for modeling", df.columns.tolist(), default=df.columns.tolist())

    if selected_features:
        # Drop NA for modeling
        df_clean = df[selected_features].dropna()

        # Isolation Forest
        clf = IsolationForest(contamination=0.05, random_state=42)
        preds = clf.fit_predict(df_clean)
        df_result = df.copy()
        df_result['Anomaly'] = np.where(preds == -1, 'Anomaly', 'Normal')

        # Show results
        st.subheader("Anomaly Detection Results")
        st.dataframe(df_result.head())

        # Summary
        st.markdown("### 📊 Anomaly Summary")
        st.write(df_result['Anomaly'].value_counts())

        # Visualize anomalies
        st.markdown("### 🧯 Anomaly Distribution Plot")
        fig, ax = plt.subplots()
        sns.countplot(data=df_result, x="Anomaly", palette="Set2", ax=ax)
        st.pyplot(fig)

        # Optional scatter plot for 2D feature visualization
        if len(selected_features) >= 2:
            f1, f2 = selected_features[:2]
            st.markdown(f"### 2D Visualization: {f1} vs {f2}")
            fig2, ax2 = plt.subplots()
            sns.scatterplot(x=df_result[f1], y=df_result[f2], hue=df_result['Anomaly'], palette="coolwarm", ax=ax2)
            st.pyplot(fig2)

else:
    st.info("Please upload a dataset to begin.")
