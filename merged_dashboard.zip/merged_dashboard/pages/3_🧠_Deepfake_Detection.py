import streamlit as st
from deepface import DeepFace
import tempfile
import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

import tensorflow as tf
# Your TensorFlow code here

st.set_page_config(page_title="🎭 Deepfake Detection", layout="wide")
st.title("🎭 Deepfake Detection using DeepFace")

st.markdown("Upload an original image and a suspected deepfake image to verify authenticity.")

# Upload two images
col1, col2 = st.columns(2)

with col1:
    original_img = st.file_uploader("Upload Original Image", type=["jpg", "jpeg", "png"], key="orig")
    if original_img:
        st.image(original_img, caption="Original", width=250)

with col2:
    suspect_img = st.file_uploader("Upload Suspected Deepfake Image", type=["jpg", "jpeg", "png"], key="suspect")
    if suspect_img:
        st.image(suspect_img, caption="Suspected Deepfake", width=250)

# Verify button
if original_img and suspect_img:
    if st.button("🧠 Verify Deepfake"):
        try:
            # Create temporary files to save the uploaded images
            with tempfile.NamedTemporaryFile(delete=False, suffix=".jpg") as orig_temp, \
                    tempfile.NamedTemporaryFile(delete=False, suffix=".jpg") as suspect_temp:
                orig_temp.write(original_img.read())
                suspect_temp.write(suspect_img.read())

                orig_temp_path = orig_temp.name
                suspect_temp_path = suspect_temp.name

            # Verify the images
            result = DeepFace.verify(
                img1_path=orig_temp_path,
                img2_path=suspect_temp_path,
                enforce_detection=False
            )
            if result["verified"]:
                st.success("✅ Images Match - No Deepfake Detected.")
            else:
                st.error("⚠ Potential Deepfake - Faces Do Not Match.")

        except Exception as e:
            st.error(f"Error during detection: {e}")
        finally:
            # Clean up temporary files
            os.remove(orig_temp_path)
            os.remove(suspect_temp_path)
else:
    st.info("Upload both images to begin detection.")